import "./index.css";
import News from "./Pages/News";
function App() {
  return (
    <>
      <News />
    </>
  );
}

export default App;
